/// Archivo: ProcesarImagen.h
/// Definición de la clase ProcesarImagen para realizar operaciones sobre imágenes.

#ifndef PROCESAR_IMAGEN_H
#define PROCESAR_IMAGEN_H

#include "imagen.h"
#include <chrono>
#include <iostream>
#include <sys/resource.h>

class ProcesarImagen {
private:
    Imagen imagen;
    bool imagenCargada;

    /// Función auxiliar para obtener el uso de memoria actual
    long obtenerMemoriaUso();
    

public:
    long memoriaIteracion;
    /// Constructor que recibe la ruta de la imagen
    ProcesarImagen(const std::string& rutaImagen);

    /// Método para invertir los colores de la imagen
    void invertirColores();

    /// Método para medir el tiempo y consumo de memoria de la operación de inversión de colores
    void medirTiempoYMemoria();

    /// Método para guardar la imagen procesada
    void guardarImagenProcesada(const std::string& nombreArchivo) const;

    /// Método para verificar si la imagen fue cargada correctamente
    bool esImagenCargada() const;
};

#endif
