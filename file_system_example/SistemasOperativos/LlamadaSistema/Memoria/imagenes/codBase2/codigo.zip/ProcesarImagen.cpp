/// Archivo: ProcesarImagen.cpp
/// Implementación de la clase ProcesarImagen

#include "ProcesarImagen.h"
#include <opencv2/opencv.hpp>
#include <sys/time.h>
#include <fstream>
#include <unistd.h>

/// Constructor que inicializa la imagen
ProcesarImagen::ProcesarImagen(const std::string& rutaImagen) : imagen(rutaImagen) {
    imagenCargada = imagen.cargarImagen();
    if (!imagenCargada) {
        std::cerr << "Error al cargar la imagen." << std::endl;
    }
}

/// Método para verificar si la imagen fue cargada correctamente
bool ProcesarImagen::esImagenCargada() const {
    return imagenCargada;
}

/// Método para obtener la memoria usada por el proceso en KB
long ProcesarImagen::obtenerMemoriaUso() {
    std::ifstream statm("/proc/self/statm");
    long size, resident;
    statm >> size >> resident;
    statm.close();
    return resident * sysconf(_SC_PAGESIZE) / 1024; // Convertir a KB
}

/// Método para invertir los colores de la imagen
void ProcesarImagen::invertirColores() {
    if (!imagenCargada) {
        std::cerr << "Error: No se puede invertir colores en una imagen no cargada." << std::endl;
        return;
    }
    int ancho = imagen.obtenerAncho();
    int alto = imagen.obtenerAlto();
    int canales = imagen.obtenerCanales();
    

    long memoriaONLINE = obtenerMemoriaUso(); 
    long memoriaONLINE2 =0;

    unsigned char* datos = imagen.obtenerDatos();
    for (int i = 0; i < ancho * alto * canales; i++) {
        datos[i] = 255 - datos[i];
        memoriaONLINE2 = obtenerMemoriaUso();
        if (memoriaONLINE < memoriaONLINE2) {   
            memoriaONLINE = memoriaONLINE2;
        }
        this->memoriaIteracion = memoriaONLINE;
    }
}

/// Método para medir el tiempo y consumo de memoria de la operación de inversión de colores
void ProcesarImagen::medirTiempoYMemoria() {
    if (!imagenCargada) {
        std::cerr << "Error: No se puede medir el tiempo en una imagen no cargada." << std::endl;
        return;
    }
    struct timeval inicio, fin;
    
    //long memoriaAntes = obtenerMemoriaUso();
    gettimeofday(&inicio, NULL);
    
    invertirColores();
    
    gettimeofday(&fin, NULL);
    long memoriaDespues = obtenerMemoriaUso();
    
    double tiempoSegundos = (fin.tv_sec - inicio.tv_sec) + (fin.tv_usec - inicio.tv_usec) / 1e6;
    //long memoriaUsada = memoriaDespues - memoriaAntes;
    long memoriaUsada = memoriaDespues - 0;//this->memoriaIteracion;
    
    
    std::cout << "Tiempo de procesamiento: " << tiempoSegundos << " segundos" << std::endl;
    std::cout << "Memoria utilizada: " << memoriaUsada << " KB" << std::endl;
}

/// Método para guardar la imagen procesada en formato PNG
void ProcesarImagen::guardarImagenProcesada(const std::string& nombreArchivo) const {
    if (!imagenCargada) {
        std::cerr << "Error: No se puede guardar una imagen no cargada." << std::endl;
        return;
    }
    imagen.guardarImagen(nombreArchivo);
}