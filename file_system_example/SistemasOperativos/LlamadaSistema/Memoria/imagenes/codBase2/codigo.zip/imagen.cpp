/// Archivo: imagen.cpp
/// Implementación de la clase Imagen para manejar archivos BMP, JPG, PNG, WEBP y GIF.

#include "imagen.h"

/// Constructor de la clase Imagen
Imagen::Imagen(const std::string& rutaArchivo) : ruta(rutaArchivo), ancho(0), alto(0), canales(0), datos(nullptr) {}

/// Destructor para liberar memoria
Imagen::~Imagen() {
    if (datos) {
        stbi_image_free(datos);
    }
}

/// Cargar la imagen y extraer la información
bool Imagen::cargarImagen() {
    datos = stbi_load(ruta.c_str(), &ancho, &alto, &canales, 0);
    if (!datos) {
        std::cerr << "Error: No se pudo cargar la imagen " << ruta << std::endl;
        return false;
    }
    return true;
}

/// Obtener el ancho de la imagen
int Imagen::obtenerAncho() const {
    return ancho;
}

/// Obtener el alto de la imagen
int Imagen::obtenerAlto() const {
    return alto;
}

/// Obtener el número de canales de la imagen
int Imagen::obtenerCanales() const {
    return canales;
}

/// Obtener los datos en bruto de la imagen
unsigned char* Imagen::obtenerDatos() const {
    return datos;
}

/// Mostrar la cabecera de la imagen en consola
void Imagen::mostrarCabecera() const {
    std::cout << "Imagen: " << ruta << std::endl;
    std::cout << "Dimensiones: " << ancho << "x" << alto << std::endl;
    std::cout << "Canales: " << canales << std::endl;
}

/// Extraer los canales RGB a matrices
void Imagen::extraerCanales() {
    canalRojo.resize(alto, std::vector<int>(ancho));
    canalVerde.resize(alto, std::vector<int>(ancho));
    canalAzul.resize(alto, std::vector<int>(ancho));
    
    for (int y = 0; y < alto; y++) {
        for (int x = 0; x < ancho; x++) {
            int index = (y * ancho + x) * canales;
            canalRojo[y][x] = datos[index];
            canalVerde[y][x] = datos[index + 1];
            canalAzul[y][x] = datos[index + 2];
        }
    }
}

/// Guardar la imagen en formato PNG
void Imagen::guardarImagen(const std::string& nombreArchivo) const {
    cv::Mat imagenOriginal(alto, ancho, CV_8UC3);
    
    for (int y = 0; y < alto; y++) {
        for (int x = 0; x < ancho; x++) {
            int index = (y * ancho + x) * canales;
            imagenOriginal.at<cv::Vec3b>(y, x) = cv::Vec3b(datos[index + 2], datos[index + 1], datos[index]);
        }
    }
    
    cv::imwrite(nombreArchivo, imagenOriginal);
}
